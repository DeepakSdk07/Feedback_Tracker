from django.shortcuts import render, redirect
from .forms import FeedbackForm      
from .models import Feedback


def submit_feedback(request):
    if request.method=="POST":
        form=FeedbackForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('feedback_list')
    else:
        form=FeedbackForm
    return render(request,'submit_feedback.html',{'form':form})

def feedback_list(request):
    feedbacks=Feedback.objects.all().order_by('-created_at')
    return render(request,'feedback_list.html',{'feedbacks':feedbacks})
