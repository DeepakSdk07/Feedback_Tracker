from django.urls import path
from .views import submit_feedback,feedback_list

urlpatterns=[
    path('',submit_feedback,name='submit_feedback'),
    path('list/',feedback_list,name='feedback_list'),
]